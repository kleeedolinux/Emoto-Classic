# 🤠 Emoto Protótipo
## Desenvolvido em TypeScript, HTML e CSS
### Jogo sobre adivinhar emotes da Twitch, feito por um nerdola para nerdolas.

# 👇 Jogue agora aqui!
https://emoto.discloud.app

Inclui os emotes da Twitch, BTTV, 7TV e FFZ
Usa a API tEmotes ->https://adiq.stoplight.io/docs/temotes/YXBpOjMyNjU2ODIx-t-emotes-api
